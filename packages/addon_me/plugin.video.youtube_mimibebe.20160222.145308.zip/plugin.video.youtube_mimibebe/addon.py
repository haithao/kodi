import os, sys
import plugintools
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import xbmc,xbmcaddon
import urllib,urllib2,re
#from addon.common.addon import Addon

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

#addonID = 'plugin.minimal.example-master'
#addon = Addon(addonID, sys.argv)
#local = xbmcaddon.Addon(id=addonID)
#icon = local.getAddonInfo('icon')
#fanart = local.getAddonInfo('fanart')
url_playlist = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_playlist.txt'
url_channel = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_channel.txt'
url_dangthanhhai = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_dangthanhhai.txt'
url_mimibebe = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_mimibebe.txt'
url_news = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_news.txt'
url_other = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_other.txt'
url_music = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_music.txt'

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)
	
# Main menu
def list_channel():
	channels = getcontent(url_channel)
	for list in channels:
		plugintools.add_item(
		title = list[1],
		url = "plugin://plugin.video.youtube/channel/" + list[0] +"/",
		#thumbnail = icon,
		folder = True
		)

def list_playlist():
	playlists = getcontent(url_playlist)
	for list in playlists:
		plugintools.add_item(
		title = list[1],
		url = "plugin://plugin.video.youtube/playlist/" + list[0] +"/",
		#thumbnail = icon,
		folder = True
		)

def list_all(href):
	playlists = getcontent(href)
	for list in playlists:
		plugintools.add_item(
		title = list[1],
		url = "plugin://plugin.video.youtube/" + list[2] + "/" + list[0] +"/",
		#thumbnail = icon,
		folder = True
		)
		
#split string : ["DangThanhHai", "UCf2BWeQ6rkCKC4CQ6HB0g_g"],["dfdgfd", "fgfhhjh"]	
def getcontent(href):
	f = []
	from urllib import urlopen
	url = urlopen(href)
	result = url.read()	
	match = re.findall('(?<=\[)[^\[\]]+', result)	
	for string in match:
		f.append(getcontent2(string))
	return f

#split string : "DangThanhHai", "UCf2BWeQ6rkCKC4CQ6HB0g_g"
def getcontent2(str):
	f = []
	match = re.findall('(?<=")[^",]+',str)
	for string in match:
		f.append(string)
	return f
	
mode = args.get('mode', None)

if mode is None:
    url = build_url({'mode': 'folder', 'foldername': 'Channel'})
    li = xbmcgui.ListItem('Channel', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'Playlist'})
    li = xbmcgui.ListItem('Playlist', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'MimiBebe'})
    li = xbmcgui.ListItem('MimiBebe', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'Music Clip'})
    li = xbmcgui.ListItem('Music Clip', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'Dang Thanh Hai'})
    li = xbmcgui.ListItem('Dang Thanh Hai', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'News'})
    li = xbmcgui.ListItem('News', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'Other'})
    li = xbmcgui.ListItem('Other', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
				
    xbmcplugin.endOfDirectory(addon_handle)	

elif mode[0] == 'folder':
	foldername = args['foldername'][0]
	if foldername == "Channel":
		list_channel()
	elif foldername == "Playlist":
		list_playlist()
	elif foldername == "MimiBebe":
		list_all(url_mimibebe)
	elif foldername == "Music Clip":
		list_all(url_music)
	elif foldername == "Dang Thanh Hai":
		list_all(url_dangthanhhai)
	elif foldername == "Other":
		list_all(url_other)
	elif foldername == "News":
		list_all(url_news)
	#li = xbmcgui.ListItem(foldername + ' Video', iconImage='DefaultVideo.png')
    #xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	xbmcplugin.endOfDirectory(addon_handle)


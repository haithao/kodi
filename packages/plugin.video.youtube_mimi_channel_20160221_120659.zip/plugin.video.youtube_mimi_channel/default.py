# -*- coding: utf-8 -*-
#------------------------------------------------------------
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
import urllib,urllib2,re
from addon.common.addon import Addon

addonID = 'plugin.video.youtube_mimi_channel'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')
myurl = 'https://raw.githubusercontent.com/haithao/kodi/master/youtube_channel'

#channels = ["UCf2BWeQ6rkCKC4CQ6HB0g_g", "UCneqF6MKRD7-V24OzOhzikw", "walleye101tv"]
#playlists = ["PLXx0W3oJrrPQAn9y-DvjGK0tSyyuj25Al"]
channels = []

# Entry point
def run():
    plugintools.log("AddictiveFishing.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("AddictiveFishing.main_list "+repr(params))
	
    for channel in channels:
		plugintools.add_item(
		title = channel[1],
		url = "plugin://plugin.video.youtube/channel/"+ channel[0] +"/",
		thumbnail = icon,
		folder = True
		)
		
#    for channel in channels:
#		plugintools.add_item(
#		title = channel,
#		url = "plugin://plugin.video.youtube/user/"+ channel +"/",
#		thumbnail = icon,
#		folder = True
#		)
#	for playlist in playlists:
#		plugintools.add_item(
#		title = playlist,
#		url = "plugin://plugin.video.youtube/playlist/"+ playlist +"/",
#		thumbnail = icon,
#		folder = True
#		)

#split string : ["DangThanhHai", "UCf2BWeQ6rkCKC4CQ6HB0g_g"],["dfdgfd", "fgfhhjh"]	
def getcontent():
	from urllib import urlopen
	url = urlopen(myurl)
	result = url.read()	
	match = re.findall('(?<=\[)[^\[\]]+', result)
	for string in match:
		channels.append(getcontent2(string))

#split string : "DangThanhHai", "UCf2BWeQ6rkCKC4CQ6HB0g_g"
def getcontent2(str):
	f = []
	match = re.findall('(?<=")[^",]+',str)
	for string in match:
		f.append(string)
	return f

getcontent()
run()
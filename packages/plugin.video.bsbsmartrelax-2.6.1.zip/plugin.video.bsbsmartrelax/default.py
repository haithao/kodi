﻿import os,sys ,urllib,urlparse,imp,xbmcaddon,base64,xbmcgui
bsbsmartrelax = xbmcaddon.Addon(); home = bsbsmartrelax.getAddonInfo('path')
sys.path.append(xbmc.translatePath(os.path.join(home, 'resources', 'core')))
sys.path.append(xbmc.translatePath(os.path.join(home, 'resources', 'lib')))
settings   = xbmcaddon.Addon()
username = settings.getSetting( "username" )
password = settings.getSetting( "password" )
url_str = 'http://smartrelax.4all.vn/index.php?option=com_kodismartrelax&task=checkAccount&u=' + base64.b64encode(username) + '&p=' +base64.b64encode(password) + '&format=raw'
dataserver = urllib.urlopen(url_str).read()
kq = dataserver.find('ERROR:',0,20)
def alert(message):
  xbmcgui.Dialog().ok("BSB Smart Relax - Thông báo!","",message)
  return
if kq ==-1 :
    from aceloader import *
    install_acestream()
    mKey = BSBGetKey()
    import parserst
    #parserst = LoadData('parserst',mKey)
    args = urlparse.parse_qs(sys.argv[2][1:])
    mode = args.get('mode', None)
    parserst.OpenMode(mode)
else:
    alert(dataserver)



